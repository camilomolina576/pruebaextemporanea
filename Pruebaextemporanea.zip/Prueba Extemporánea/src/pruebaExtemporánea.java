import java.util.Scanner;

public class pruebaExtempor�nea {
	public static void datosPersonales (String nombreEscuela,String telefonoEscuela, String ciudadEscuela, String direccionEscuela,  String directorEscuela, String cedulaDirector, String profesionDirector) {
		System.out.println("El nombre de la escuela es: " + nombreEscuela);
		System.out.println("El telefono es de escuela es: " + telefonoEscuela);
		System.out.println("La escuela esta en la ciudad de: " + ciudadEscuela);
		System.out.println("La direccion de la escuela es: " + direccionEscuela);
		System.out.println("El director de la escuela es : " + directorEscuela);
		System.out.println("La cedula del director es : " + cedulaDirector);
		System.out.println("La profesion del director es: " + profesionDirector);
	}
	
		
	public static void main (String[] args ) {
		Scanner teclado = new Scanner (System.in);
		String nombreEscuela,telefonoEscuela,ciudadEscuela;
		System.out.println("Introduce el nombre de la escuela ");
		nombreEscuela = teclado.next();
		System.out.println("Introduce el telefono de la escuela ");
		telefonoEscuela = teclado.next();
		System.out.println("Introduce la ciudad donde la escuela esta ubicada ");
		ciudadEscuela = teclado.next();
		System.out.println("Introduce la direccion de la escuela y el barrio en el que esta ubicada ");
		String direccionEscuela = teclado.next();
		System.out.println("Introduce el nombre del director de la escuela  ");
		String directorEscuela = teclado.next();		
		System.out.println("Introduce la cedula del director de la escuela ");
		String cedulaDirector = teclado.next();
		System.out.println("Introduce la profesion del director de la escuela ");
		String profesionDirector = teclado.next();
	
		datosPersonales ( nombreEscuela,telefonoEscuela, ciudadEscuela, direccionEscuela, directorEscuela, cedulaDirector, profesionDirector);
	}
	}
